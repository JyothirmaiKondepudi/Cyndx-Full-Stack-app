class EmailAlreadyExistsException(Exception):
    pass