package com.app.form_management_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormManagementServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormManagementServiceApplication.class, args);
	}

}
