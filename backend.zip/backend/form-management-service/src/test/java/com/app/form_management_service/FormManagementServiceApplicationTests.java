package com.app.form_management_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
